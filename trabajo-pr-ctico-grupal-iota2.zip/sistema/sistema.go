package sistema

type SistemaSIGOA struct {
	aeronaves   Aeronaves
	aeropuertos Aeropuertos
	clientes    Clientes
	edificios   Edificios

	cargas   []*Carga
	vuelos   []*Vuelo
	reservas []*Reserva
}

func NewSistemaSIGOA() *SistemaSIGOA {
	return &SistemaSIGOA{}
}

func (s *SistemaSIGOA) Aeronaves() *Aeronaves {
	return &s.aeronaves
}

func (s *SistemaSIGOA) Aeropuertos() *Aeropuertos {
	return &s.aeropuertos
}

func (s *SistemaSIGOA) Clientes() *Clientes {
	return &s.clientes
}

func (s *SistemaSIGOA) Edificios() *Edificios {
	return &s.edificios
}
