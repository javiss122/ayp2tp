package simulador

import (
	"sigoa/sistema"
	"time"
)

type Simulador struct {
	sigoa       *sistema.SistemaSIGOA
	personas    []*Persona
	mostradores []*Mostrador
	hora        time.Time // Hora dentro de la simulación
}

func NewSimulador(sigoa *sistema.SistemaSIGOA) *Simulador {
	return &Simulador{
		sigoa: sigoa,
	}
}

func (s *Simulador) Iniciar() {
	// TODO: cargar personas necesarias para la simulación
	// TODO: establecer hora antes del primer vuelo, cerca del checkin
	// TODO: imprimir información de la simulacion (aeropuertos simulados, cantidad de personas, hora actual)
}

// Devuelve true si aún hay vuelos por realizar
func (s *Simulador) DebeContinuar() bool {
	return false
}

// Ejecuta un tick de la simulación
func (s *Simulador) Tick() {
	// TODO: procesar
	s.hora = s.hora.Add(time.Minute)
}
